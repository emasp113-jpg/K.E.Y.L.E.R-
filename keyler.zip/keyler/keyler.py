"""K.E.Y.L.E.R - un asistente de IA con personalidad propia, hecho con la API de Claude."""
import os
import sys

import anthropic
from dotenv import load_dotenv

load_dotenv()

MODEL = os.getenv("KEYLER_MODEL", "claude-sonnet-5-5")

SYSTEM_PROMPT = """Eres K.E.Y.L.E.R, una IA creada por tu usuario.
Personalidad: curiosa, directa, con un toque de humor. Hablas en español natural.
Reglas: sé claro y breve, admite cuando no sabes algo, y nunca inventes datos.
Si el usuario te pide ayuda con algo, primero da la respuesta y luego los detalles."""


def main() -> None:
    if not os.getenv("ANTHROPIC_API_KEY"):
        sys.exit("Falta ANTHROPIC_API_KEY. Copia .env.example a .env y ponla ahí.")

    client = anthropic.Anthropic()
    history = []
    print("K.E.Y.L.E.R en línea. Escribe 'salir' para terminar.\n")

    while True:
        user_input = input("Tú: ").strip()
        if user_input.lower() in {"salir", "exit", "quit"}:
            print("K.E.Y.L.E.R: Hasta pronto.")
            break
        if not user_input:
            continue

        history.append({"role": "user", "content": user_input})
        print("K.E.Y.L.E.R: ", end="", flush=True)

        reply = ""
        with client.messages.stream(
            model=MODEL,
            max_tokens=1000,
            system=SYSTEM_PROMPT,
            messages=history,
        ) as stream:
            for text in stream.text_stream:
                print(text, end="", flush=True)
                reply += text
        print("\n")

        history.append({"role": "assistant", "content": reply})


if __name__ == "__main__":
    main()
