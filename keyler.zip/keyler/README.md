# K.E.Y.L.E.R

Una IA con personalidad propia, construida sobre la API de Claude.

## Instalación

```bash
git clone https://github.com/TU_USUARIO/keyler.git
cd keyler
pip install -r requirements.txt
cp .env.example .env   # y pon tu ANTHROPIC_API_KEY
python keyler.py
```

## Personalizar

Edita `SYSTEM_PROMPT` en `keyler.py` para cambiar su personalidad.

## Licencia

MIT
