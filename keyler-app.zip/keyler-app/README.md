# Keyler — la llave de tus ideas

App Android de una sola IA: Keyler, creativa y motivadora, que te ayuda a destrabar y ordenar tus ideas.

## Estructura
```
.github/workflows/apk.yml   Crea el APK automáticamente en GitHub
www/index.html              La app (pantalla de inicio, chat y ajustes)
capacitor.config.json       Convierte la web en app Android
package.json                Dependencias
logo/keyler.svg             Logo
personalidad.md             Personalidad
```

## Cómo obtener el APK
1. Sube todos los archivos a un repositorio de GitHub (la carpeta `.github` debe quedar tal cual).
2. Pestaña **Actions** > **Crear APK de Keyler** > **Run workflow** (también corre solo al subir cambios).
3. Cuando termine, descarga **keyler-apk** en Artifacts, descomprime e instala `app-debug.apk`.

## Usar a Keyler
Abre la app, entra a **Ajustes** y pega tu API key de Anthropic. Se guarda solo en tu teléfono. **Nunca la pongas en el código ni la subas a GitHub.**
